from django.urls import path,include
from . import views
from .views import UpdateBookView,BookView
from rest_framework import routers



urlpatterns = [
    path("", views.index, name="index"),
    path("add_book/", views.add_book, name="add_book"),
    path("view_books/", views.view_books, name="view_books"),
    path("view_student_books/", views.view_student_books, name="view_student_books"),
    path("view_students/", views.view_students, name="view_students"),
    path("profile/", views.profile, name="profile"),
    path("edit_profile/", views.edit_profile, name="edit_profile"),
    path("book_api/", BookView.as_view(), name="book_api"),
    path("student_registration/", views.student_registration, name="student_registration"),
    path("student_login/", views.student_login, name="student_login"),
    path("admin_login/", views.admin_login, name="admin_login"),
    path("logout/", views.Logout, name="logout"),
    path('books/edit/<int:pk>',UpdateBookView.as_view(), name = 'update_book'),
    path("delete_book/<int:myid>/", views.delete_book, name="delete_book"),
    path("delete_student/<int:myid>/", views.delete_student, name="delete_student"),






]