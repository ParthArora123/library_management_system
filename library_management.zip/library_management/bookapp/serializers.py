from rest_framework import serializers

from .models import Book
from django import forms

class BookSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Book
        fields = (
            'name',
            'author',
            'isbn',
            'category'
        )